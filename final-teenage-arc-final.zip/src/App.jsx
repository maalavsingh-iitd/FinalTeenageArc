import React, { useEffect, useMemo, useState } from "react";
import {
  Activity, ArrowDownRight, ArrowUpRight, CalendarDays, Check, CheckCheck, Timer, BookOpen, Pause, Play, RotateCcw, FileVideo,
  ChevronLeft, ChevronRight, Circle, Clock3, Download, Flag, Flame, Image,
  LayoutDashboard, ListTodo, LockKeyhole, Plus, Save, Settings2, Sparkles,
  Target, Trash2, Trophy, X, Zap, CheckCircle2, CalendarRange, Link2
} from "lucide-react";
import {
  Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
  Bar, BarChart
} from "recharts";

const TARGET = "2027-01-05";
const DEFAULT_TASKS = [
  { id: "physique", title: "Train / move", category: "Physique", points: 2 },
  { id: "abs-core", title: "Abs / core session OR planned recovery", category: "Abs Arc", points: 2 },
  { id: "protein", title: "Hit protein target", category: "Physique", points: 1 },
  { id: "calorie-plan", title: "Follow a sustainable food plan", category: "Abs Arc", points: 2 },
  { id: "steps", title: "Reach my step / movement goal", category: "Abs Arc", points: 1 },
  { id: "sleep", title: "Get 7.5–9 hours of sleep", category: "Abs Arc", points: 1 },
  { id: "checkin", title: "Morning weigh-in / weekly trend check", category: "Abs Arc", points: 1 },
  { id: "deepwork", title: "One focused work block", category: "Career", points: 2 },
  { id: "dsa", title: "DSA practice", category: "Career", points: 2 },
  { id: "academics", title: "College academics", category: "Academics", points: 2 },
  { id: "read", title: "Read 10 pages", category: "Growth", points: 1 },
  { id: "journal", title: "Capture a memory / journal", category: "Life", points: 1 }
];
const NAV = [
  ["Countdown", Clock3],
  ["Today", LayoutDashboard],
  ["Journey", Activity],
  ["Daily tasks", ListTodo],
  ["Memories", Image],
  ["Milestones", Flag],
  ["Weekly review", CalendarDays],
  ["Focus mode", Timer],
  ["Retrospective", BookOpen]
];
const dateKey = (d = new Date()) => {
  const x = new Date(d);
  return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,"0")}-${String(x.getDate()).padStart(2,"0")}`;
};
const fromKey = (key) => new Date(`${key}T12:00:00`);
const dayDiff = (a,b) => Math.floor((fromKey(b)-fromKey(a))/86400000);
const prettyDate = (key, options = { weekday:"short", month:"short", day:"numeric" }) =>
  fromKey(key).toLocaleDateString("en-US", options);
const clamp = (n,min,max) => Math.max(min,Math.min(max,n));
function readStore() {
  try { return JSON.parse(localStorage.getItem("fta-v2-store") || "{}"); } catch { return {}; }
}
function readFocusTimer() {
  try {
    const saved = JSON.parse(localStorage.getItem("fta-focus-timer") || "null");
    return saved && typeof saved === "object" ? saved : {};
  } catch { return {}; }
}
function IconButton({ children, onClick, title, className="" }) {
  return <button className={`icon-button ${className}`} onClick={onClick} title={title}>{children}</button>;
}
function ProgressRing({ value=0, size=94, stroke=7 }) {
  const r=(size-stroke)/2, c=2*Math.PI*r;
  return <div className="ring-wrap" style={{width:size,height:size}}>
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="ring">
      <circle cx={size/2} cy={size/2} r={r} stroke="rgba(255,255,255,.09)" strokeWidth={stroke} fill="none"/>
      <circle cx={size/2} cy={size/2} r={r} stroke="var(--accent)" strokeWidth={stroke} strokeLinecap="round" fill="none"
        strokeDasharray={c} strokeDashoffset={c-(clamp(value,0,100)/100)*c} transform={`rotate(-90 ${size/2} ${size/2})`}/>
    </svg>
    <div className="ring-label"><strong>{Math.round(value)}%</strong><span>complete</span></div>
  </div>;
}
function App() {
  const [store,setStore] = useState(() => {
    const s=readStore();
    return {
      tasks: Array.isArray(s.tasks) ? [...s.tasks, ...DEFAULT_TASKS.filter(t => !s.tasks.some(old => old.id === t.id))] : DEFAULT_TASKS,
      logs: s.logs || {},
      memories: s.memories || [],
      milestones: s.milestones || [],
      reviews: s.reviews || {},
      weeklyPlans: s.weeklyPlans || {},
      completedGoals: s.completedGoals || [],
      settings: s.settings || { name:"Final Teenage Arc", dailyNote:"" }
    };
  });
  const [page,setPage] = useState("Countdown");
  const [clockNow,setClockNow] = useState(Date.now());
  const [focusMinutes,setFocusMinutes] = useState(()=>{const saved=readFocusTimer();return [25,50,90].includes(saved.minutes)?saved.minutes:50;});
  const [focusEndAt,setFocusEndAt] = useState(()=>{const saved=readFocusTimer();return saved.running&&Number.isFinite(saved.endAt)&&saved.endAt>Date.now()?saved.endAt:null;});
  const [focusSecondsLeft,setFocusSecondsLeft] = useState(()=>{const saved=readFocusTimer();if(saved.running&&Number.isFinite(saved.endAt))return Math.max(0,Math.ceil((saved.endAt-Date.now())/1000));return Number.isFinite(saved.remainingSeconds)?Math.max(0,Math.floor(saved.remainingSeconds)):50*60;});
  const [focusRunning,setFocusRunning] = useState(()=>{const saved=readFocusTimer();return Boolean(saved.running&&Number.isFinite(saved.endAt)&&saved.endAt>Date.now());});
  const [focusLabel,setFocusLabel] = useState(()=>{const saved=readFocusTimer();return typeof saved.label==="string"&&saved.label.trim()?saved.label:"Deep work";});
  const [focusSessions,setFocusSessions] = useState(()=>{try{return JSON.parse(localStorage.getItem("fta-focus-sessions")||"[]")}catch{return []}});
  const [memoryMediaDraft,setMemoryMediaDraft] = useState([]);
  const [selectedDate,setSelectedDate] = useState(dateKey());
  const [taskDraft,setTaskDraft] = useState("");
  const [categoryDraft,setCategoryDraft] = useState("Growth");
  const [editingTask,setEditingTask] = useState(null);
  const [memoryDraft,setMemoryDraft] = useState({title:"",note:"",date:dateKey()});
  const [milestoneDraft,setMilestoneDraft] = useState({title:"",date:dateKey(),detail:"",type:"milestone"});
  const [reviewDraft,setReviewDraft] = useState("");
  const [weeklyOutcomeDraft,setWeeklyOutcomeDraft] = useState({title:"",detail:"",goalId:"",dueDate:""});
  const [toast,setToast] = useState("");
  const [celebrate,setCelebrate] = useState(false);
  const [chartRange,setChartRange] = useState("30");
  const today = dateKey();
  const currentLog = store.logs[selectedDate] || { completed:[], note:"" };
  const tasks = store.tasks;
  const completed = currentLog.completed || [];
  const progress = tasks.length ? completed.filter(id=>tasks.some(t=>t.id===id)).length/tasks.length*100 : 0;
  const points = tasks.filter(t=>completed.includes(t.id)).reduce((sum,t)=>sum+(t.points||1),0);
  const totalPoints = tasks.reduce((sum,t)=>sum+(t.points||1),0);
  const daysLeft = Math.max(0,dayDiff(today,TARGET));
  const elapsed = Math.max(0,dayDiff("2026-10-07",today));
  const totalArcDays = Math.max(1,dayDiff("2026-10-07",TARGET)+1);
  const daysElapsed = clamp(elapsed+1,0,totalArcDays);
  const weekStartDate = (key=today) => { const d=fromKey(key); const offset=(d.getDay()+6)%7; d.setDate(d.getDate()-offset); return dateKey(d); };
  const weekEndDate = (key=today) => { const d=fromKey(weekStartDate(key)); d.setDate(d.getDate()+6); return dateKey(d); };
  const currentWeekKey = weekStartDate(today);
  const currentWeekPlan = store.weeklyPlans?.[currentWeekKey] || { outcomes:[] };
  const weeklyOutcomes = currentWeekPlan.outcomes || [];
  const weeklyDone = weeklyOutcomes.filter(o=>o.completed).length;
  const addWeeklyOutcome = () => {
    const title=weeklyOutcomeDraft.title.trim(); if(!title) return;
    const outcome={id:`outcome-${Date.now()}`,title,detail:weeklyOutcomeDraft.detail.trim(),goalId:weeklyOutcomeDraft.goalId||"",dueDate:weeklyOutcomeDraft.dueDate||weekEndDate(),completed:false,createdAt:today};
    setStore(s=>({...s,weeklyPlans:{...(s.weeklyPlans||{}),[currentWeekKey]:{...(s.weeklyPlans?.[currentWeekKey]||{}),outcomes:[...(s.weeklyPlans?.[currentWeekKey]?.outcomes||[]),outcome]}}}));
    setWeeklyOutcomeDraft({title:"",detail:"",goalId:"",dueDate:""}); setToast("Weekly outcome added");
  };
  const toggleWeeklyOutcome = id => setStore(s=>({...s,weeklyPlans:{...(s.weeklyPlans||{}),[currentWeekKey]:{...(s.weeklyPlans?.[currentWeekKey]||{}),outcomes:(s.weeklyPlans?.[currentWeekKey]?.outcomes||[]).map(o=>o.id===id?{...o,completed:!o.completed,completedAt:!o.completed?today:null}:o)}}}));
  const deleteWeeklyOutcome = id => setStore(s=>({...s,weeklyPlans:{...(s.weeklyPlans||{}),[currentWeekKey]:{...(s.weeklyPlans?.[currentWeekKey]||{}),outcomes:(s.weeklyPlans?.[currentWeekKey]?.outcomes||[]).filter(o=>o.id!==id)}}}));

  useEffect(()=>{ try{localStorage.setItem("fta-v2-store",JSON.stringify(store));}catch{setToast("Browser storage is nearly full. Export a backup and remove large media files.");} },[store]);
  useEffect(()=>{try{localStorage.setItem("fta-focus-sessions",JSON.stringify(focusSessions));}catch{}},[focusSessions]);
  useEffect(()=>{
    const syncClock=()=>setClockNow(Date.now());
    const syncWhenVisible=()=>{if(document.visibilityState==="visible")syncClock();};
    syncClock();
    const timer=setInterval(syncClock,1000);
    window.addEventListener("focus",syncClock);
    window.addEventListener("pageshow",syncClock);
    document.addEventListener("visibilitychange",syncWhenVisible);
    return ()=>{clearInterval(timer);window.removeEventListener("focus",syncClock);window.removeEventListener("pageshow",syncClock);document.removeEventListener("visibilitychange",syncWhenVisible);};
  },[]);
  useEffect(()=>{
    if(!focusRunning||!focusEndAt)return;
    const updateRemaining=()=>{
      const remaining=Math.max(0,Math.ceil((focusEndAt-Date.now())/1000));
      setFocusSecondsLeft(current=>current===remaining?current:remaining);
      if(remaining===0){setFocusRunning(false);setFocusEndAt(null);setToast("Focus session time is up. Review and log what you accomplished.");}
    };
    updateRemaining();
    const timer=setInterval(updateRemaining,1000);
    window.addEventListener("focus",updateRemaining);
    window.addEventListener("pageshow",updateRemaining);
    document.addEventListener("visibilitychange",updateRemaining);
    return ()=>{clearInterval(timer);window.removeEventListener("focus",updateRemaining);window.removeEventListener("pageshow",updateRemaining);document.removeEventListener("visibilitychange",updateRemaining);};
  },[focusRunning,focusEndAt]);
  useEffect(()=>{
    try{
      const remaining=focusRunning&&focusEndAt?Math.max(0,Math.ceil((focusEndAt-Date.now())/1000)):focusSecondsLeft;
      localStorage.setItem("fta-focus-timer",JSON.stringify({minutes:focusMinutes,label:focusLabel,running:Boolean(focusRunning&&focusEndAt),endAt:focusRunning?focusEndAt:null,remainingSeconds:remaining}));
    }catch{}
  },[focusMinutes,focusLabel,focusSecondsLeft,focusRunning,focusEndAt]);
  useEffect(()=>{ if(toast){ const t=setTimeout(()=>setToast(""),2600); return ()=>clearTimeout(t); } },[toast]);
  useEffect(()=>{ setReviewDraft(store.reviews[today] || ""); },[today,store.reviews]);

  const updateLog = (date, updater) => setStore(s => {
    const old=s.logs[date] || {completed:[],note:""};
    return {...s,logs:{...s.logs,[date]:updater(old)}};
  });
  const toggleTask = id => {
    const wasDone=completed.includes(id);
    const next=wasDone ? completed.filter(x=>x!==id) : [...completed,id];
    updateLog(selectedDate,l=>({...l,completed:next}));
    if(!wasDone && next.length===tasks.length && tasks.length>0 && selectedDate===today){
      setCelebrate(true); setToast("All tasks complete. You showed up today.");
      setTimeout(()=>setCelebrate(false),2400);
    } else if(!wasDone) setToast("Progress saved");
  };
  const addTask = () => {
    const title=taskDraft.trim();
    if(!title) return;
    setStore(s=>({...s,tasks:[...s.tasks,{id:`task-${Date.now()}`,title,category:categoryDraft,points:1}]}));
    setTaskDraft(""); setToast("Task added to your daily list");
  };
  const saveTaskEdit = () => {
    if(!editingTask) return;
    const title=editingTask.title.trim();
    if(!title) return;
    setStore(s=>({...s,tasks:s.tasks.map(t=>t.id===editingTask.id?{...t,...editingTask,title}:t)}));
    setEditingTask(null); setToast("Task updated");
  };
  const deleteTask = id => {
    setStore(s=>({...s,tasks:s.tasks.filter(t=>t.id!==id)}));
    setToast("Task removed");
  };
  const chartData = useMemo(()=>{
    const n=Number(chartRange), dates=[];
    for(let i=n-1;i>=0;i--){
      const d=new Date(); d.setDate(d.getDate()-i); const key=dateKey(d);
      const log=store.logs[key] || {completed:[]};
      const pct=tasks.length ? Math.round((log.completed||[]).filter(id=>tasks.some(t=>t.id===id)).length/tasks.length*100):0;
      dates.push({date:key,label:fromKey(key).toLocaleDateString("en-US",{month:"short",day:"numeric"}),progress:pct,done:(log.completed||[]).length,full:pct===100});
    }
    return dates;
  },[store.logs,tasks,chartRange]);
  const arcData = useMemo(()=>{
    const start=fromKey("2026-10-07"), end=fromKey(TARGET), now=fromKey(today);
    const days=Math.max(1,Math.min(90,Math.floor((end-start)/86400000)+1));
    let running=0;
    return Array.from({length:days},(_,i)=>{
      const d=new Date(start); d.setDate(d.getDate()+i); const key=dateKey(d);
      const log=store.logs[key]||{completed:[]};
      const pct=tasks.length ? Math.round((log.completed||[]).filter(id=>tasks.some(t=>t.id===id)).length/tasks.length*100):0;
      if(d<=now) running+=pct;
      return {day:i+1,label:prettyDate(key,{month:"short",day:"numeric"}),daily:pct,average:d<=now?Math.round(running/(i+1)):null,done:(log.completed||[]).length};
    });
  },[store.logs,tasks,today]);
  const streak = useMemo(()=>{
    let count=0, d=fromKey(today);
    while(count<365){
      const key=dateKey(d), log=store.logs[key];
      if(!log || !(log.completed||[]).length) break;
      count++; d.setDate(d.getDate()-1);
    }
    return count;
  },[store.logs,today]);
  const daysWithWork = Object.entries(store.logs).filter(([d,l])=>d<=today && (l.completed||[]).length>0).length;
  const avgProgress = chartData.filter(d=>d.date<=today).length ? Math.round(chartData.filter(d=>d.date<=today).reduce((a,b)=>a+b.progress,0)/chartData.filter(d=>d.date<=today).length):0;
  const exportData = () => {
    const blob=new Blob([JSON.stringify({...store,focusSessions,exportedAt:new Date().toISOString()},null,2)],{type:"application/json"});
    const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download="final-teenage-arc-backup.json"; a.click(); URL.revokeObjectURL(url);
  };
  const importBackup = e => {
    const file=e.target.files?.[0]; if(!file)return;
    const reader=new FileReader(); reader.onload=()=>{try{const parsed=JSON.parse(reader.result); if(parsed.logs&&parsed.tasks){setStore(s=>({...s,...parsed}));if(Array.isArray(parsed.focusSessions))setFocusSessions(parsed.focusSessions);setToast("Backup restored");}else setToast("That file doesn't look like an Arc backup");}catch{setToast("Could not read backup");}};
    reader.readAsText(file); e.target.value="";
  };
  const saveMemory = () => {
    if(!memoryDraft.title.trim()) return;
    setStore(s=>({...s,memories:[{...memoryDraft,media:memoryMediaDraft,id:Date.now()},...s.memories]}));
    setMemoryDraft({title:"",note:"",date:today}); setMemoryMediaDraft([]); setToast("Memory saved");
  };
  const handleMemoryMedia = e => {
    const files=Array.from(e.target.files||[]);
    const oversized=files.find(f=>f.size>2*1024*1024);
    if(oversized){setToast("Each media file must be 700 KB or smaller for browser storage");e.target.value="";return;}
    Promise.all(files.map(file=>new Promise(resolve=>{const reader=new FileReader();reader.onload=()=>resolve({name:file.name,type:file.type,data:reader.result});reader.readAsDataURL(file);}))).then(items=>setMemoryMediaDraft(old=>[...old,...items].slice(0,3)));
    e.target.value="";
  };
  const toggleFocusTimer = () => {
    if(focusRunning){
      const remaining=focusEndAt?Math.max(0,Math.ceil((focusEndAt-Date.now())/1000)):focusSecondsLeft;
      setFocusSecondsLeft(remaining);setFocusRunning(false);setFocusEndAt(null);return;
    }
    const remaining=focusSecondsLeft>0?focusSecondsLeft:focusMinutes*60;
    setFocusSecondsLeft(remaining);setFocusEndAt(Date.now()+remaining*1000);setFocusRunning(true);
  };
  const resetFocusTimer = () => {setFocusRunning(false);setFocusEndAt(null);setFocusSecondsLeft(focusMinutes*60);};
  const finishFocusSession = () => {
    const remaining=focusRunning&&focusEndAt?Math.max(0,Math.ceil((focusEndAt-Date.now())/1000)):focusSecondsLeft;
    const spent=Math.max(0,Math.round((focusMinutes*60-remaining)/60));
    if(spent<1){setToast("Complete at least one minute before logging a session");return;}
    setFocusSessions(s=>[{id:Date.now(),label:focusLabel.trim()||"Focus session",minutes:spent,date:today},...s]);
    setFocusRunning(false);setFocusEndAt(null);setFocusSecondsLeft(focusMinutes*60);setToast(`${spent} focused minutes logged`);
  };
  const saveMilestone = () => {
    if(!milestoneDraft.title.trim())return;
    setStore(s=>({...s,milestones:[{...milestoneDraft,id:Date.now(),type:milestoneDraft.type||"milestone"},...s.milestones]}));
    const wasGoal=milestoneDraft.type==="goal";
    setMilestoneDraft({title:"",date:today,detail:"",type:"milestone"}); setToast(wasGoal?"Long-term goal added":"Milestone added");
  };
  const completeGoal = goal => {
    setStore(s=>({...s,milestones:s.milestones.filter(x=>x.id!==goal.id),completedGoals:[...(s.completedGoals||[]),{...goal,completedAt:today}]}));
    setToast("Goal completed — removed from active goals");
  };
  const saveReview = () => {
    setStore(s=>({...s,reviews:{...s.reviews,[today]:reviewDraft}})); setToast("Weekly reflection saved");
  };
  const countdownParts = (() => {
    const diff = Math.max(0, new Date(`${TARGET}T00:00:00`).getTime() - clockNow);
    return { days: Math.floor(diff/86400000), hours: Math.floor(diff%86400000/3600000), minutes: Math.floor(diff%3600000/60000), seconds: Math.floor(diff%60000/1000) };
  })();
  const renderCountdown = () => <main className="countdown-screen">
    <div className="countdown-screen-grain"/><div className="countdown-screen-orbit orbit-one"/><div className="countdown-screen-orbit orbit-two"/>
    <div className="countdown-screen-top"><span className="brand-mark">FTA<span>✳</span></span><span className="countdown-screen-kicker"><i/> THE FINAL TEENAGE ARC</span></div>
    <section className="countdown-screen-center"><span className="eyebrow">JANUARY 05, 2027 · THE NEXT CHAPTER</span><h1>Time doesn't <em>wait.</em></h1><p className="countdown-screen-sub">One life. A finite number of days. Make this chapter count.</p>
      <div className="countdown-units">{[[countdownParts.days,"DAYS"],[countdownParts.hours,"HOURS"],[countdownParts.minutes,"MINUTES"],[countdownParts.seconds,"SECONDS"]].map(([n,label])=><div className="countdown-unit" key={label}><strong>{String(n).padStart(2,"0")}</strong><span>{label}</span></div>)}</div>
      <div className="countdown-screen-rule"><i/></div><p className="countdown-screen-mantra">DON'T JUST WATCH THE CLOCK. <b>GIVE IT A REASON.</b></p>
      <button className="countdown-enter" onClick={()=>setPage("Today")}>ENTER THE ARC <ArrowDownRight size={17}/></button>
    </section><div className="countdown-screen-bottom"><span>YOUR DAYS. YOUR PROOF.</span><span>COUNT EVERY ONE.</span></div>
  </main>;
  const renderHeader = () => <header className="topbar">
    <div className="brand-mark">FTA<span>✳</span></div>
    <div className="topbar-meta"><span className="live-dot"></span> YOUR PERSONAL ERA / 2026—27</div>
    <div className="top-actions"><button className="text-button" onClick={exportData}><Download size={15}/> Backup data</button><label className="text-button import-button"><Save size={15}/> Restore<input type="file" accept=".json,application/json" onChange={importBackup}/></label></div>
  </header>;
  const renderSidebar = () => <aside className="sidebar">
    <div className="side-intro"><span className="eyebrow">THE PERSONAL ARCHIVE</span><h2>Make it<br/><em>count.</em></h2><p>Small actions. A life you can look back on.</p></div>
    <nav>{NAV.map(([name,Icon])=><button key={name} className={`nav-item ${page===name?"active":""}`} onClick={()=>setPage(name)}><Icon size={17}/><span>{name}</span>{name==="Today"&&<span className="nav-dot"/>}</button>)}</nav>
    <div className="side-bottom"><div className="privacy-note"><LockKeyhole size={15}/><span>Private by default<br/><b>Saved in this browser</b></span></div><div className="side-edition">EDITION 01 <span>·</span> THE BECOMING</div></div>
  </aside>;
  const renderToday = () => <div className="page-content">
    <div className="page-heading"><div><span className="eyebrow">{prettyDate(today,{weekday:"long",month:"long",day:"numeric",year:"numeric"})}</span><h1>Show up <em>today.</em></h1><p>Consistency is built on ordinary days like this one.</p></div><div className="date-chip"><CalendarDays size={16}/><span>DAY {daysElapsed} / {totalArcDays}</span></div></div>
    <section className="hero-grid">
      <div className="card countdown-card"><div className="card-top"><span className="eyebrow">THE COUNTDOWN</span><span className="pill"><span className="live-dot"/> IN PROGRESS</span></div><div className="count-number">{daysLeft}<span> days left</span></div><p>Until January 5, 2027.</p><div className="count-track"><div style={{width:`${daysElapsed/totalArcDays*100}%`}}/></div><div className="count-foot"><span>OCT 07, 2026</span><span>JAN 05, 2027</span></div><div className="count-quote">“You don't rise to the level of your goals. You fall to the level of your systems.”</div></div>
      <div className={`card daily-score ${celebrate?"celebrate":""}`}><div className="card-top"><span className="eyebrow">TODAY'S SCORE</span><Sparkles size={17} className="sparkle"/></div><div className="score-main"><ProgressRing value={progress}/><div><div className="score-big">{completed.length}<span> / {tasks.length}</span></div><div className="score-caption">tasks completed</div><div className="score-points"><Zap size={14}/>{points} points earned</div></div></div><div className="score-message">{progress===100&&tasks.length?"All done. Let yourself feel that.":progress>=50?"You're past halfway. Keep the promise.":"Start small. Build momentum."}</div></div>
    </section>
    <section className="section-head"><div><span className="eyebrow">YOUR DAILY SYSTEM</span><h2>Today's commitments</h2></div><button className="inline-link" onClick={()=>setPage("Daily tasks")}>Edit task list <ChevronRight size={16}/></button></section>
    <section className="card task-card">
      {tasks.length===0?<div className="empty-state"><ListTodo size={26}/><h3>No tasks yet</h3><p>Add the commitments you want to track each day.</p><button className="primary-button" onClick={()=>setPage("Daily tasks")}>Create daily tasks</button></div>:tasks.map((task,i)=>{
        const done=completed.includes(task.id);
        return <button key={task.id} className={`task-row ${done?"is-done":""}`} onClick={()=>toggleTask(task.id)}>
          <span className={`task-check ${done?"checked":""}`}>{done?<Check size={15}/>:<span>{String(i+1).padStart(2,"0")}</span>}</span>
          <span className="task-copy"><strong>{task.title}</strong><small>{task.category}</small></span>
          <span className="task-points">+{task.points||1} XP</span>
          <span className="task-end">{done?<CheckCheck size={18}/>:<Circle size={17}/>}</span>
        </button>;
      })}
      <div className="task-card-foot"><span>{completed.length===tasks.length&&tasks.length>0?"Daily commitments complete":`${tasks.length-completed.length} left to go`}</span><span className="micro-progress"><i style={{width:`${progress}%`}}/></span></div>
    </section>
    <section className="section-head long-goals-heading"><div><span className="eyebrow">THIS WEEK, MADE CONCRETE</span><h2>Weekly outcomes</h2><p>Small set of meaningful results to move your bigger goals forward.</p></div><button className="inline-link" onClick={()=>setPage("Weekly review")}>Plan this week <ChevronRight size={16}/></button></section>
    <section className="weekly-outcomes-today card">
      <div className="weekly-outcome-progress"><div><span className="eyebrow">WEEK OF {prettyDate(currentWeekKey,{month:"short",day:"numeric"}).toUpperCase()} – {prettyDate(weekEndDate(),{month:"short",day:"numeric"}).toUpperCase()}</span><strong>{weeklyDone}<small> / {weeklyOutcomes.length} complete</small></strong></div><div className="weekly-progress-track"><i style={{width:`${weeklyOutcomes.length?weeklyDone/weeklyOutcomes.length*100:0}%`}}/></div></div>
      {weeklyOutcomes.length ? <div className="today-outcome-list">{weeklyOutcomes.map(o=>{const linked=(store.milestones||[]).find(g=>g.id===o.goalId);return <div className={`today-outcome-row ${o.completed?"is-complete":""}`} key={o.id}><button className="outcome-check" onClick={()=>toggleWeeklyOutcome(o.id)} aria-label={o.completed?"Mark outcome incomplete":"Complete outcome"}>{o.completed?<CheckCircle2 size={19}/>:<Circle size={19}/>}</button><div className="today-outcome-copy"><strong>{o.title}</strong>{o.detail&&<p>{o.detail}</p>}<small>{linked?<><Link2 size={11}/> {linked.title} · </>:null}Due {prettyDate(o.dueDate,{month:"short",day:"numeric"})}</small></div></div>})}</div> : <div className="weekly-outcome-empty"><CalendarRange size={20}/><span>No weekly outcomes yet. Choose up to three results that would make this week count.</span><button className="inline-link" onClick={()=>setPage("Weekly review")}>Build weekly plan <ChevronRight size={14}/></button></div>}
    </section>
    <section className="section-head long-goals-heading"><div><span className="eyebrow">THE BIGGER PROMISES</span><h2>Long-term goals</h2><p>Keep the next milestone in sight while you work on today's tasks.</p></div><button className="inline-link" onClick={()=>setPage("Milestones")}>Manage goals <ChevronRight size={16}/></button></section>
    <section className="long-goals-grid">
      {(store.milestones||[]).filter(m=>m.type==="goal").sort((a,b)=>a.date.localeCompare(b.date)).map(goal=>{
        const remaining=dayDiff(today,goal.date); const overdue=remaining<0;
        return <article className={`card long-goal-card ${overdue?"goal-overdue":""}`} key={goal.id}>
          <div className="long-goal-top"><span className="goal-tag"><Target size={13}/> LONG-TERM GOAL</span><span className="goal-deadline">{overdue?`${Math.abs(remaining)}d overdue`:remaining===0?"Due today":`${remaining}d left`}</span></div>
          <h3>{goal.title}</h3><p>{goal.detail||"One promise at a time."}</p>
          <div className="long-goal-foot"><span><CalendarDays size={13}/> Due {prettyDate(goal.date,{month:"short",day:"numeric",year:"numeric"})}</span><button className="primary-button" onClick={()=>completeGoal(goal)}><Check size={14}/> Complete goal</button></div>
        </article>;
      })}
      {!(store.milestones||[]).some(m=>m.type==="goal")&&<div className="card long-goal-empty"><Target size={23}/><div><strong>No active long-term goals yet.</strong><p>Add a weekly goal or deadline in Milestones and it'll appear here beside your daily system.</p></div><button className="inline-link" onClick={()=>{setMilestoneDraft(d=>({...d,type:"goal",date:today}));setPage("Milestones");}}>Add a goal <ChevronRight size={15}/></button></div>}
    </section>
    <section className="bottom-grid">
      <div className="card mini-chart"><div className="section-head compact"><div><span className="eyebrow">RECENT MOMENTUM</span><h3>Work, day by day</h3></div><button className="inline-link" onClick={()=>setPage("Journey")}>Full journey <ChevronRight size={15}/></button></div><div className="chart-wrap short"><ResponsiveContainer width="100%" height="100%"><AreaChart data={chartData.slice(-7)} margin={{top:8,right:5,left:-28,bottom:0}}><defs><linearGradient id="todayGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#c7f36b" stopOpacity={.25}/><stop offset="100%" stopColor="#c7f36b" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="rgba(255,255,255,.06)" vertical={false}/><XAxis dataKey="label" tick={{fill:"#888d86",fontSize:10}} axisLine={false} tickLine={false}/><YAxis domain={[0,100]} tick={{fill:"#888d86",fontSize:10}} axisLine={false} tickLine={false}/><Tooltip contentStyle={{background:"#1c201b",border:"1px solid #373c32",borderRadius:10,color:"#f4f4ec"}} formatter={(v)=>[`${v}%`,"Daily completion"]}/><Area type="monotone" dataKey="progress" stroke="#c7f36b" strokeWidth={2} fill="url(#todayGradient)"/></AreaChart></ResponsiveContainer></div></div>
      <div className="card quick-stats"><span className="eyebrow">KEEP THE THREAD</span><div className="stat-line"><div className="stat-icon"><Flame size={17}/></div><div><strong>{streak} day{streak===1?"":"s"}</strong><small>active streak</small></div></div><div className="stat-line"><div className="stat-icon"><Target size={17}/></div><div><strong>{daysWithWork} day{daysWithWork===1?"":"s"}</strong><small>days with progress</small></div></div><div className="stat-line"><div className="stat-icon"><Trophy size={17}/></div><div><strong>{store.milestones.length}</strong><small>milestones recorded</small></div></div></div>
    </section>
  </div>;
  const renderJourney = () => <div className="page-content">
    <div className="page-heading"><div><span className="eyebrow">THE BIG PICTURE</span><h1>Your journey, <em>so far.</em></h1><p>Don't just remember the days. See the effort add up.</p></div><div className="date-chip"><Activity size={16}/><span>{daysElapsed} DAYS IN</span></div></div>
    <section className="journey-countdown card">
      <div className="journey-countdown-grain" aria-hidden="true"/>
      <div className="journey-countdown-copy">
        <span className="eyebrow"><span className="live-dot"/> THE CLOCK IS RUNNING</span>
        <h2>Make these days <em>mean something.</em></h2>
        <p>Not someday. Not when you feel ready. The life you want is built in the time you have left.</p>
        <div className="journey-countdown-date"><CalendarDays size={15}/> JANUARY 05, 2027 <span>·</span> YOUR NEXT CHAPTER
        </div>
      </div>
      <div className="journey-countdown-number">
        <strong>{daysLeft}</strong><span>DAYS<br/>REMAINING</span>
        <div className="journey-countdown-track"><i style={{width:`${daysElapsed/totalArcDays*100}%`}}/></div>
        <small>{daysElapsed} of {totalArcDays} days elapsed</small>
      </div>
      <div className="journey-countdown-orbit" aria-hidden="true"><i/><i/><i/></div>
    </section>
    <section className="journey-metrics">
      <div className="card metric-card"><span className="eyebrow">DAYS WITH ACTION</span><strong>{daysWithWork}<small> days</small></strong><div className="metric-foot"><ArrowUpRight size={14}/> Days you showed up</div></div>
      <div className="card metric-card"><span className="eyebrow">AVERAGE COMPLETION</span><strong>{avgProgress}<small>%</small></strong><div className="metric-foot"><Activity size={14}/> Daily tasks completed</div></div>
      <div className="card metric-card"><span className="eyebrow">CURRENT STREAK</span><strong>{streak}<small> days</small></strong><div className="metric-foot"><Flame size={14}/> Keep the thread alive</div></div>
      <div className="card metric-card accent-metric"><span className="eyebrow">TOTAL TASKS DONE</span><strong>{Object.values(store.logs).reduce((a,l)=>a+(l.completed||[]).length,0)}</strong><div className="metric-foot"><CheckCheck size={14}/> Small wins, counted</div></div>
    </section>
    <section className="card chart-card"><div className="chart-header"><div><span className="eyebrow">DAILY CONSISTENCY</span><h2>Effort across the days</h2><p>Each point is the percentage of your daily task list completed.</p></div><div className="segmented"><button className={chartRange==="7"?"selected":""} onClick={()=>setChartRange("7")}>7D</button><button className={chartRange==="30"?"selected":""} onClick={()=>setChartRange("30")}>30D</button><button className={chartRange==="90"?"selected":""} onClick={()=>setChartRange("90")}>90D</button></div></div>
      <div className="chart-wrap tall"><ResponsiveContainer width="100%" height="100%"><AreaChart data={chartData} margin={{top:14,right:12,left:-20,bottom:0}}><defs><linearGradient id="journeyGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#c7f36b" stopOpacity={.28}/><stop offset="100%" stopColor="#c7f36b" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="rgba(255,255,255,.07)" vertical={false}/><XAxis dataKey="label" interval={chartRange==="7"?0:Math.ceil(Number(chartRange)/7)} tick={{fill:"#8d928a",fontSize:11}} axisLine={false} tickLine={false}/><YAxis domain={[0,100]} ticks={[0,25,50,75,100]} tickFormatter={v=>`${v}%`} tick={{fill:"#8d928a",fontSize:11}} axisLine={false} tickLine={false}/><Tooltip contentStyle={{background:"#1c201b",border:"1px solid #373c32",borderRadius:10,color:"#f4f4ec"}} labelStyle={{color:"#c7f36b"}} formatter={(v)=>[`${v}%`,"Tasks completed"]}/><Area type="monotone" dataKey="progress" stroke="#c7f36b" strokeWidth={2.5} activeDot={{r:5,fill:"#c7f36b",stroke:"#101110",strokeWidth:2}} fill="url(#journeyGradient)"/></AreaChart></ResponsiveContainer></div>
      <div className="chart-legend"><span><i className="legend-dot"/> Daily completion</span><span className="muted">Empty days show 0% — not missing data.</span></div>
    </section>
    <section className="journey-lower">
      <div className="card chart-card"><div className="chart-header"><div><span className="eyebrow">DAY-BY-DAY RECORD</span><h3>Consistency calendar</h3><p>A quick visual scan of your recent effort.</p></div></div><div className="heatmap">{Array.from({length:56},(_,i)=>{const d=new Date();d.setDate(d.getDate()-(55-i));const key=dateKey(d);const log=store.logs[key]||{completed:[]};const pct=tasks.length?Math.round((log.completed||[]).filter(id=>tasks.some(t=>t.id===id)).length/tasks.length*100):0;return <button key={key} className={`heat-cell level-${pct===0?0:pct<35?1:pct<70?2:pct<100?3:4}`} title={`${prettyDate(key,{month:"short",day:"numeric"})}: ${pct}% complete`} onClick={()=>{setSelectedDate(key);setPage("Today");}}/>})}</div><div className="heat-legend"><span>Less</span>{[0,1,2,3,4].map(n=><i key={n} className={`heat-cell level-${n}`}/>)}<span>More</span></div></div>
      <div className="card milestones-preview"><div className="section-head compact"><div><span className="eyebrow">MILESTONES</span><h3>Proof of progress</h3></div><button className="inline-link" onClick={()=>setPage("Milestones")}>View all <ChevronRight size={15}/></button></div>{store.milestones.length?store.milestones.slice(0,3).map(m=><div className="milestone-line" key={m.id}><span className="milestone-dot"><Flag size={13}/></span><div><strong>{m.title}</strong><small>{prettyDate(m.date,{month:"short",day:"numeric",year:"numeric"})}</small></div></div>):<div className="empty-inline"><Trophy size={22}/><p>Your story will have milestones.<br/>Record the first one when it happens.</p><button className="inline-link" onClick={()=>setPage("Milestones")}>Add milestone <ChevronRight size={15}/></button></div>}</div>
    </section>
    <section className="card journey-note"><Sparkles size={20}/><div><strong>The point isn't a perfect graph.</strong><p>It's making your effort visible. A low day is information, not a verdict. Keep logging honestly and the picture becomes useful.</p></div></section>
  </div>;
  const renderTasks = () => <div className="page-content">
    <div className="page-heading"><div><span className="eyebrow">YOUR SYSTEM, YOUR RULES</span><h1>Daily <em>tasks.</em></h1><p>Edit the commitments you want to see each day. Changes apply to every date.</p></div><div className="date-chip"><Settings2 size={16}/><span>EDITABLE LIST</span></div></div>
    <section className="card task-editor"><div className="section-head"><div><span className="eyebrow">TASK LIBRARY</span><h2>Your daily commitments</h2></div><span className="count-badge">{tasks.length} tasks</span></div>
      <div className="editor-list">{tasks.map((task,i)=><div className="editor-row" key={task.id}>
        {editingTask?.id===task.id?<div className="edit-fields"><input value={editingTask.title} onChange={e=>setEditingTask({...editingTask,title:e.target.value})} onKeyDown={e=>e.key==="Enter"&&saveTaskEdit()} autoFocus/><select value={editingTask.category} onChange={e=>setEditingTask({...editingTask,category:e.target.value})}>{["Physique","Career","Academics","Growth","Life","Discipline","Custom"].map(c=><option key={c}>{c}</option>)}</select><select value={editingTask.points||1} onChange={e=>setEditingTask({...editingTask,points:Number(e.target.value)})}><option value={1}>1 XP</option><option value={2}>2 XP</option><option value={3}>3 XP</option></select><button className="small-icon success" onClick={saveTaskEdit} title="Save"><Check size={16}/></button><button className="small-icon" onClick={()=>setEditingTask(null)} title="Cancel"><X size={16}/></button></div>
        :<><span className="editor-index">{String(i+1).padStart(2,"0")}</span><div className="editor-task-text"><strong>{task.title}</strong><small>{task.category} · {task.points||1} XP</small></div><button className="small-icon" onClick={()=>setEditingTask({...task})} title="Edit task"><Settings2 size={16}/></button><button className="small-icon danger" onClick={()=>deleteTask(task.id)} title="Delete task"><Trash2 size={16}/></button></>}
      </div>)}</div>
      <div className="add-task-form"><div className="eyebrow">ADD A COMMITMENT</div><div className="add-fields"><input placeholder="e.g. Practise video editing for 1 hour" value={taskDraft} onChange={e=>setTaskDraft(e.target.value)} onKeyDown={e=>e.key==="Enter"&&addTask()}/><select value={categoryDraft} onChange={e=>setCategoryDraft(e.target.value)}>{["Physique","Career","Academics","Growth","Life","Discipline","Custom"].map(c=><option key={c}>{c}</option>)}</select><button className="primary-button" onClick={addTask}><Plus size={16}/> Add task</button></div></div>
      <div className="editor-tip"><Sparkles size={17}/><p><strong>Make the list yours.</strong> Keep it realistic enough to repeat. You can edit titles, categories, and XP at any time. Completed history stays recorded against the task IDs.</p></div>
    </section>
  </div>;
  const renderFocus = () => <div className="page-content">
    <div className="page-heading"><div><span className="eyebrow">ONE THING AT A TIME</span><h1>Focus <em>mode.</em></h1><p>Choose the work. Protect the time. Record what moved.</p></div><div className="date-chip"><Timer size={16}/><span>{focusSessions.reduce((n,x)=>n+x.minutes,0)} MIN LOGGED TODAY</span></div></div>
    <section className="focus-layout"><div className="card focus-main"><span className="eyebrow">CURRENT SESSION</span><label className="focus-label">What are you working on?<input value={focusLabel} onChange={e=>setFocusLabel(e.target.value)} placeholder="e.g. Solve 3 graph problems" disabled={focusRunning}/></label><div className="focus-clock" aria-live="polite">{String(Math.floor(focusSecondsLeft/60)).padStart(2,"0")}<span>:</span>{String(focusSecondsLeft%60).padStart(2,"0")}</div><div className="focus-presets">{[25,50,90].map(n=><button key={n} className={focusMinutes===n?"selected":""} disabled={focusRunning} onClick={()=>{setFocusMinutes(n);setFocusEndAt(null);setFocusSecondsLeft(n*60)}}>{n} min</button>)}</div><div className="focus-controls"><button className="primary-button" onClick={toggleFocusTimer}>{focusRunning?<><Pause size={16}/> Pause session</>:<><Play size={16}/> {focusSecondsLeft<focusMinutes*60?"Resume focus":"Start focus"}</>}</button><button className="secondary-button" onClick={resetFocusTimer}><RotateCcw size={15}/> Reset</button><button className="secondary-button" onClick={finishFocusSession}><Check size={15}/> Finish & log</button></div><p className="form-hint">The timer uses an absolute end time and catches up when you return, even after closing the browser. Your device cannot guarantee a sound or notification while the site is fully closed.</p></div><aside className="card focus-guide"><span className="eyebrow">THE CONTRACT</span><h2>Before you begin</h2><p>Write a specific finish line, silence distractions, and work on one thing only.</p><div className="focus-rule"/><h3>Today's focus</h3><strong>{focusSessions.filter(x=>x.date===today).reduce((n,x)=>n+x.minutes,0)} min</strong><small>of logged deep work</small><div className="focus-rule"/><p className="form-hint">A session counts when you deliberately stop, record what you achieved, and choose the next step.</p></aside></section>
    <div className="section-head"><div><span className="eyebrow">SESSION HISTORY</span><h2>Evidence of focus</h2></div><span className="count-badge">{focusSessions.length} sessions</span></div><section className="focus-history">{focusSessions.map(x=><article className="card focus-history-row" key={x.id}><div className="focus-history-icon"><Timer size={17}/></div><div><strong>{x.label}</strong><small>{prettyDate(x.date,{month:"short",day:"numeric",year:"numeric"})}</small></div><b>{x.minutes} min</b><IconButton title="Delete session" onClick={()=>setFocusSessions(s=>s.filter(y=>y.id!==x.id))}><Trash2 size={15}/></IconButton></article>)}{!focusSessions.length&&<div className="card empty-state"><Timer size={28}/><h3>Your first focus session starts here</h3><p>Log the work you actually complete. Your focus history is saved in this browser.</p></div>}</section>
  </div>;
  const renderRetrospective = () => {
    const completedTasks=Object.values(store.logs).reduce((n,l)=>n+(l.completed||[]).length,0);
    const totalFocus=focusSessions.reduce((n,x)=>n+x.minutes,0);
    const completedOutcomes=Object.values(store.weeklyPlans||{}).flatMap(w=>w.outcomes||[]).filter(o=>o.completed).length;
    const daysWithProgress=Object.entries(store.logs).filter(([d,l])=>d<=today&&(l.completed||[]).length>0).length;
    return <div className="page-content"><div className="page-heading"><div><span className="eyebrow">THE RECORD, NOT THE MYTH</span><h1>The <em>retrospective.</em></h1><p>A living summary of what you did, what changed, and what you want to remember.</p></div><button className="primary-button" onClick={exportData}><Download size={15}/> Export full backup</button></div><section className="retro-hero card"><span className="eyebrow">FINAL TEENAGE ARC · JAN 05, 2027</span><h2>Make the story <em>real.</em></h2><p>This is a snapshot of the data you've recorded in this browser. It grows as you plan, work, and reflect.</p></section><section className="retro-metrics"><div className="card metric-card"><span className="eyebrow">TASK CHECKS</span><strong>{completedTasks}</strong><div className="metric-foot">Recorded completions across all days</div></div><div className="card metric-card"><span className="eyebrow">DAYS WITH ACTION</span><strong>{daysWithProgress}</strong><div className="metric-foot">Days with at least one checked task</div></div><div className="card metric-card"><span className="eyebrow">WEEKLY OUTCOMES</span><strong>{completedOutcomes}</strong><div className="metric-foot">Outcomes marked complete</div></div><div className="card metric-card"><span className="eyebrow">MEMORIES</span><strong>{store.memories.length}</strong><div className="metric-foot">Moments preserved</div></div></section><section className="retro-columns"><div className="card retro-section"><span className="eyebrow">PROMISES KEPT</span><h2>Long-term goals completed</h2>{(store.completedGoals||[]).map(g=><div className="retro-line" key={g.id}><CheckCircle2 size={16}/><div><strong>{g.title}</strong><small>Completed {prettyDate(g.completedAt||g.date,{month:"short",day:"numeric",year:"numeric"})}</small></div></div>)}{!(store.completedGoals||[]).length&&<p className="form-hint">Completed goals will appear here when you mark them done.</p>}</div><div className="card retro-section"><span className="eyebrow">MOMENTS THAT MATTER</span><h2>Memory timeline</h2>{store.memories.slice(0,6).map(m=><div className="retro-line" key={m.id}><BookOpen size={16}/><div><strong>{m.title}</strong><small>{prettyDate(m.date,{month:"short",day:"numeric",year:"numeric"})}</small></div></div>)}{!store.memories.length&&<p className="form-hint">Save a few notes or photos in Memories to build your timeline.</p>}</div></section><section className="card retro-section"><span className="eyebrow">THE NEXT CHAPTER</span><h2>What did this era teach you?</h2><p>Use your weekly reflections to capture what worked and what you want to carry forward. Export your backup before changing devices or clearing browser data.</p><div className="retro-actions"><button className="primary-button" onClick={()=>setPage("Weekly review")}><CalendarDays size={15}/> Review the week</button><button className="secondary-button" onClick={()=>setPage("Memories")}><Image size={15}/> Add a memory</button></div></section></div>;
  };
  const renderMemories = () => <div className="page-content">
    <div className="page-heading"><div><span className="eyebrow">A RECORD OF BEING HERE</span><h1>Memory <em>archive.</em></h1><p>Save the small moments you don't want to forget.</p></div><div className="date-chip"><Image size={16}/><span>{store.memories.length} MEMORIES</span></div></div>
    <section className="card form-card"><span className="eyebrow">CAPTURE A MOMENT</span><h2>Put it into words.</h2><div className="form-grid"><label>Title<input value={memoryDraft.title} onChange={e=>setMemoryDraft({...memoryDraft,title:e.target.value})} placeholder="What happened?" /></label><label>Date<input type="date" value={memoryDraft.date} onChange={e=>setMemoryDraft({...memoryDraft,date:e.target.value})}/></label><label className="wide">Note<textarea rows="3" value={memoryDraft.note} onChange={e=>setMemoryDraft({...memoryDraft,note:e.target.value})} placeholder="What do you want future-you to remember?"/></label><label className="wide">Photos / short clips<input type="file" accept="image/*,video/*" multiple onChange={handleMemoryMedia}/><small className="form-hint">Up to 3 files, 700 KB each. Stored in this browser; back up regularly.</small></label></div>{memoryMediaDraft.length>0&&<div className="media-pending">{memoryMediaDraft.map((m,i)=><span key={i}>{m.name} <button onClick={()=>setMemoryMediaDraft(a=>a.filter((_,j)=>i!==j))}>×</button></span>)}</div>}<button className="primary-button" onClick={saveMemory}><Plus size={16}/> Save memory</button><p className="form-hint">Memories are saved locally in this browser. Media files are size-limited; keep originals and export a backup regularly.</p></section>
    <section className="memory-list">{store.memories.map(m=><article className="card memory-card" key={m.id}><div className="memory-date">{prettyDate(m.date,{month:"short",day:"numeric",year:"numeric"})}</div><h3>{m.title}</h3><p>{m.note||"A moment worth keeping."}</p>{(m.media||[]).map((media,i)=>media.type?.startsWith("image/")?<img className="memory-media-image" key={i} src={media.data} alt={media.name}/>:media.type?.startsWith("video/")?<video className="memory-media-video" key={i} src={media.data} controls preload="metadata"/>:null)}<IconButton title="Delete memory" onClick={()=>setStore(s=>({...s,memories:s.memories.filter(x=>x.id!==m.id)}))}><Trash2 size={15}/></IconButton></article>)}{!store.memories.length&&<div className="card empty-state"><Image size={28}/><h3>Your archive starts here</h3><p>Record a memory, an achievement, a conversation, or an ordinary day you want to remember.</p></div>}</section>
  </div>;
  const renderMilestones = () => <div className="page-content">
    <div className="page-heading"><div><span className="eyebrow">MILESTONES, NOT JUST METRICS</span><h1>Proof of <em>progress.</em></h1><p>Keep a record of things that mattered enough to mark.</p></div><div className="date-chip"><Flag size={16}/><span>{store.milestones.length} MARKED</span></div></div>
    <section className="card form-card"><span className="eyebrow">PLAN OR RECORD A MILESTONE</span><h2>Add a goal or mark a win.</h2><div className="goal-type-switch"><button className={milestoneDraft.type!=="goal"?"selected":""} onClick={()=>setMilestoneDraft({...milestoneDraft,type:"milestone"})}><Flag size={15}/> Completed milestone</button><button className={milestoneDraft.type==="goal"?"selected":""} onClick={()=>setMilestoneDraft({...milestoneDraft,type:"goal"})}><Target size={15}/> Long-term goal</button></div><div className="form-grid"><label>{milestoneDraft.type==="goal"?"Goal":"Milestone"}<input value={milestoneDraft.title} onChange={e=>setMilestoneDraft({...milestoneDraft,title:e.target.value})} placeholder={milestoneDraft.type==="goal"?"e.g. Finish 3 portfolio projects":"e.g. First complete week of editing"} /></label><label>{milestoneDraft.type==="goal"?"Deadline":"Date"}<input type="date" value={milestoneDraft.date} onChange={e=>setMilestoneDraft({...milestoneDraft,date:e.target.value})}/></label><label className="wide">Details<textarea rows="2" value={milestoneDraft.detail} onChange={e=>setMilestoneDraft({...milestoneDraft,detail:e.target.value})} placeholder={milestoneDraft.type==="goal"?"What does done look like?":"Why does this matter?"}/></label></div><button className="primary-button" onClick={saveMilestone}><Plus size={16}/> {milestoneDraft.type==="goal"?"Add long-term goal":"Add milestone"}</button></section>
    <div className="section-head"><div><span className="eyebrow">ACTIVE GOALS</span><h2>Deadlines to keep in sight</h2></div><span className="count-badge">{store.milestones.filter(m=>m.type==="goal").length} active</span></div>
    <section className="milestone-list">{[...store.milestones].filter(m=>m.type==="goal").sort((a,b)=>a.date.localeCompare(b.date)).map(m=><article className="card milestone-card long-goal-manage" key={m.id}><div className="milestone-emblem"><Target size={18}/></div><div className="milestone-info"><span className="eyebrow">DEADLINE · {prettyDate(m.date,{month:"long",day:"numeric",year:"numeric"})}</span><h3>{m.title}</h3><p>{m.detail||"A promise with a deadline."}</p><button className="inline-link goal-complete-link" onClick={()=>completeGoal(m)}><Check size={14}/> Mark complete & remove</button></div><IconButton title="Delete goal" onClick={()=>setStore(s=>({...s,milestones:s.milestones.filter(x=>x.id!==m.id)}))}><Trash2 size={15}/></IconButton></article>)}{!store.milestones.some(m=>m.type==="goal")&&<div className="card empty-state"><Target size={26}/><h3>No active goals</h3><p>Add weekly goals, project targets, or other deadline-based commitments above. They'll appear on your Today screen.</p></div>}</section>
    <div className="section-head"><div><span className="eyebrow">COMPLETED GOALS</span><h2>Promises kept</h2><p>Finished goals stay here as proof of what you followed through on.</p></div><span className="count-badge">{(store.completedGoals||[]).length} completed</span></div>
    <section className="milestone-list">{[...(store.completedGoals||[])].sort((a,b)=>(b.completedAt||"").localeCompare(a.completedAt||"")).map(g=><article className="card milestone-card completed-goal-card" key={g.id}><div className="milestone-emblem"><CheckCircle2 size={18}/></div><div className="milestone-info"><span className="eyebrow">COMPLETED · {prettyDate(g.completedAt||g.date,{month:"long",day:"numeric",year:"numeric"})}</span><h3>{g.title}</h3><p>{g.detail||"A promise kept."}</p></div></article>)}{!(store.completedGoals||[]).length&&<div className="card empty-state compact-empty"><CheckCircle2 size={24}/><h3>Your first completed goal will live here</h3><p>Active goals move into this archive when you mark them complete.</p></div>}</section>
    <div className="section-head"><div><span className="eyebrow">MILESTONE ARCHIVE</span><h2>Wins worth remembering</h2></div></div>
    <section className="milestone-list">{[...store.milestones].filter(m=>m.type!=="goal").sort((a,b)=>b.date.localeCompare(a.date)).map(m=><article className="card milestone-card" key={m.id}><div className="milestone-emblem"><Flag size={18}/></div><div className="milestone-info"><span className="eyebrow">{prettyDate(m.date,{month:"long",day:"numeric",year:"numeric"})}</span><h3>{m.title}</h3><p>{m.detail||"A moment in the making."}</p></div><IconButton title="Delete milestone" onClick={()=>setStore(s=>({...s,milestones:s.milestones.filter(x=>x.id!==m.id)}))}><Trash2 size={15}/></IconButton></article>)}{!store.milestones.some(m=>m.type!=="goal")&&<div className="card empty-state"><Trophy size={28}/><h3>Your first milestone is ahead</h3><p>Record it when you finish a project, reach a goal, or do something you once thought difficult.</p></div>}</section>
  </div>;
  const renderReview = () => <div className="page-content">
    <div className="page-heading"><div><span className="eyebrow">PLAN THE WORK · REVIEW THE EVIDENCE</span><h1>Weekly <em>reset.</em></h1><p>Pick a few outcomes. Connect them to a bigger promise. Then do the work.</p></div><div className="date-chip"><CalendarDays size={16}/><span>{prettyDate(currentWeekKey,{month:"short",day:"numeric"}).toUpperCase()} – {prettyDate(weekEndDate(),{month:"short",day:"numeric"}).toUpperCase()}</span></div></div>
    <section className="weekly-plan-hero card"><div className="weekly-plan-hero-copy"><span className="eyebrow">THE WEEKLY CONTRACT</span><h2>Make this week <em>count.</em></h2><p>Three meaningful outcomes are better than twenty vague intentions. Keep the list honest and achievable.</p></div><div className="weekly-plan-score"><span className="eyebrow">OUTCOMES COMPLETE</span><strong>{weeklyDone}<i> / {weeklyOutcomes.length}</i></strong><div className="weekly-progress-track"><i style={{width:`${weeklyOutcomes.length?weeklyDone/weeklyOutcomes.length*100:0}%`}}/></div><small>{weeklyOutcomes.length?Math.round(weeklyDone/weeklyOutcomes.length*100)+"% of this week's outcomes": "Your week is still unwritten"}</small></div></section>
    <section className="weekly-planning-layout">
      <div className="weekly-planning-main">
        <section className="card form-card weekly-outcome-form"><span className="eyebrow">ADD AN OUTCOME</span><h2>What would make this week a win?</h2><div className="form-grid"><label className="wide">Outcome title<input value={weeklyOutcomeDraft.title} onChange={e=>setWeeklyOutcomeDraft({...weeklyOutcomeDraft,title:e.target.value})} placeholder="e.g. Finish linked lists and solve 12 problems" /></label><label>Deadline<input type="date" min={currentWeekKey} max={weekEndDate()} value={weeklyOutcomeDraft.dueDate} onChange={e=>setWeeklyOutcomeDraft({...weeklyOutcomeDraft,dueDate:e.target.value})}/></label><label>Linked long-term goal<select value={weeklyOutcomeDraft.goalId} onChange={e=>setWeeklyOutcomeDraft({...weeklyOutcomeDraft,goalId:e.target.value})}><option value="">No linked goal</option>{(store.milestones||[]).filter(m=>m.type==="goal").map(g=><option key={g.id} value={g.id}>{g.title}</option>)}</select></label><label className="wide">Definition of done (optional)<textarea rows="2" value={weeklyOutcomeDraft.detail} onChange={e=>setWeeklyOutcomeDraft({...weeklyOutcomeDraft,detail:e.target.value})} placeholder="Make it measurable. What does finished actually mean?"/></label></div><button className="primary-button" onClick={addWeeklyOutcome} disabled={!weeklyOutcomeDraft.title.trim()}><Plus size={16}/> Add weekly outcome</button><p className="form-hint">Aim for 1–3 outcomes. Deadlines default to Sunday, and each outcome can support one of your long-term goals.</p></section>
        <div className="section-head"><div><span className="eyebrow">YOUR COMMITMENTS</span><h2>This week's outcomes</h2></div><span className="count-badge">{weeklyOutcomes.length} planned</span></div>
        <section className="weekly-outcome-list">{weeklyOutcomes.slice().sort((a,b)=>Number(a.completed)-Number(b.completed)||a.dueDate.localeCompare(b.dueDate)).map((o,i)=>{const linked=(store.milestones||[]).find(g=>g.id===o.goalId);const overdue=!o.completed&&o.dueDate<today;return <article className={`card weekly-outcome-card ${o.completed?"is-complete":""} ${overdue?"outcome-overdue":""}`} key={o.id}><button className="outcome-check" onClick={()=>toggleWeeklyOutcome(o.id)} aria-label={o.completed?"Mark outcome incomplete":"Complete outcome"}>{o.completed?<CheckCircle2 size={20}/>:<Circle size={20}/>}</button><div className="weekly-outcome-card-copy"><div className="weekly-outcome-card-top"><span className="eyebrow">OUTCOME {String(i+1).padStart(2,"0")}</span><span className={`outcome-deadline ${overdue?"overdue":""}`}>{o.completed?"COMPLETED":overdue?"OVERDUE":o.dueDate===today?"DUE TODAY":`${Math.max(0,dayDiff(today,o.dueDate))}d left`}</span></div><h3>{o.title}</h3>{o.detail&&<p>{o.detail}</p>}<div className="weekly-outcome-meta"><span><CalendarDays size={13}/> Due {prettyDate(o.dueDate,{month:"short",day:"numeric"})}</span>{linked&&<span><Link2 size={13}/> {linked.title}</span>}</div></div><IconButton title="Remove outcome" onClick={()=>deleteWeeklyOutcome(o.id)}><Trash2 size={15}/></IconButton></article>})}{!weeklyOutcomes.length&&<div className="card empty-state"><Target size={27}/><h3>Start with three priorities</h3><p>Choose the results that will matter most by the end of this week. You can add, complete, or remove outcomes any time.</p></div>}</section>
      </div>
      <aside className="weekly-planning-side"><section className="card weekly-guide-card"><span className="eyebrow">A USEFUL FILTER</span><h3>Is it an outcome?</h3><p>“Study DSA” is an activity. “Solve 12 linked-list problems and review mistakes” is an outcome.</p><div className="weekly-guide-rule"/><p>Every outcome should answer: <strong>what will be different by Sunday?</strong></p></section><section className="card weekly-goals-card"><div className="section-head compact"><div><span className="eyebrow">THE BIGGER PICTURE</span><h3>Active goals</h3></div><button className="inline-link" onClick={()=>setPage("Milestones")}>Manage <ChevronRight size={14}/></button></div>{(store.milestones||[]).filter(m=>m.type==="goal").sort((a,b)=>a.date.localeCompare(b.date)).slice(0,3).map(g=><div className="weekly-goal-link" key={g.id}><Target size={15}/><div><strong>{g.title}</strong><small>Due {prettyDate(g.date,{month:"short",day:"numeric"})}</small></div></div>)}{!(store.milestones||[]).some(m=>m.type==="goal")&&<p className="form-hint">Add a long-term goal in Milestones to link weekly outcomes to it.</p>}</section></aside>
    </section>
    <div className="section-head"><div><span className="eyebrow">CLOSE THE LOOP</span><h2>Review the week</h2><p>Review the evidence, not just the mood.</p></div></div>
    <section className="review-summary"><div className="card metric-card"><span className="eyebrow">DAILY TASK AVG.</span><strong>{Math.round(chartData.slice(-7).reduce((a,d)=>a+d.progress,0)/Math.max(1,chartData.slice(-7).length))}%</strong><div className="metric-foot">Daily habit completion</div></div><div className="card metric-card"><span className="eyebrow">OUTCOMES COMPLETE</span><strong>{weeklyDone}<small> / {weeklyOutcomes.length}</small></strong><div className="metric-foot">Meaningful results delivered</div></div><div className="card metric-card"><span className="eyebrow">DAYS WITH ACTION</span><strong>{chartData.slice(-7).filter(d=>d.done>0).length}<small> / 7</small></strong><div className="metric-foot">Any progress counts</div></div></section>
    <section className="card review-card"><span className="eyebrow">REFLECTION · {prettyDate(today,{month:"long",day:"numeric"})}</span><h2>What did this week teach you?</h2><div className="reflection-prompts"><span>01 · What went well?</span><span>02 · What got in the way?</span><span>03 · What changes next week?</span></div><textarea rows="7" value={reviewDraft} onChange={e=>setReviewDraft(e.target.value)} placeholder={"What am I proud of?\nWhat did I avoid?\nWhat will I do differently next week?"}/><button className="primary-button" onClick={saveReview}><Save size={16}/> Save reflection</button></section>
  </div>;
  const renderPage = () => {
    if(page === "Countdown") return renderCountdown();
    switch(page){case "Focus mode":return renderFocus();case "Retrospective":return renderRetrospective();case "Journey":return renderJourney();case "Daily tasks":return renderTasks();case "Memories":return renderMemories();case "Milestones":return renderMilestones();case "Weekly review":return renderReview();default:return renderToday();}
  };
  if(page === "Countdown") return <div className="countdown-app">{renderCountdown()}</div>;
  return <div className="app-shell">{renderHeader()}<div className="layout">{renderSidebar()}<main className="main-content">{renderPage()}<footer className="footer"><span>FINAL TEENAGE ARC</span><span>BUILD A LIFE YOU'RE GLAD YOU REMEMBER.</span></footer></main></div>{toast&&<div className={`toast ${celebrate?"toast-celebrate":""}`}><Sparkles size={17}/>{toast}</div>}{celebrate&&<div className="celebration-overlay"><div className="celebration-card"><div className="celebration-icon"><Trophy size={32}/></div><span className="eyebrow">A DAY WELL USED</span><h2>You showed up.<br/><em>All the way.</em></h2><p>Every promise kept is evidence. Let yourself feel the win.</p><button className="primary-button" onClick={()=>{setCelebrate(false);setPage("Journey");}}>See my journey <ArrowUpRight size={16}/></button></div></div>}</div>;
}
export default App;
