# Final Teenage Arc — Complete Edition

A local-first React + Vite personal command centre for planning, execution, and preserving the story of your Arc.

## Included
- Full-screen live countdown to January 5, 2027.
- Daily checklist with editable tasks, progress, and Abs Arc habits.
- Long-term goals with deadlines and a completed-goals archive.
- Weekly outcomes linked to long-term goals, weekly review, and reflections.
- Journey charts, consistency heatmap, memories, and milestone archive.
- **Focus Mode:** 25-, 50-, and 90-minute sessions. It uses an absolute end timestamp and persists running/paused state, so it catches up after a hidden tab or browser restart. Completed sessions are logged separately.
- **Memory media:** attach a small number of compressed photos or short clips to a memory. Each file is limited to 700 KB to reduce browser storage failures. Keep original media elsewhere.
- **Retrospective:** roll-up stats, completed goals, and memory timeline.
- JSON export/restore including goals, plans, memories, logs, and focus session history.

## Run locally
Requires Node.js 18 or newer.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. For a production build:

```bash
npm run build
npm run preview
```

## Data and privacy
Data is saved in browser localStorage on the current browser/origin. It is not synced between devices. Export a JSON backup regularly, especially before clearing browser data or changing ports. Uploaded media is embedded in browser storage and intentionally size-limited; store full-resolution photos and videos in a separate drive. Browser storage can still fill up, so keep backups and originals.

## Known limits
- While the site is closed, browser JavaScript is not running and notifications are not guaranteed. The focus timer recalculates from its saved end timestamp on return, but cannot guarantee an audible alert while fully closed.
- The retrospective summarizes data recorded in this browser, not untracked activity.
- No account, cloud sync, or remote database is included.
